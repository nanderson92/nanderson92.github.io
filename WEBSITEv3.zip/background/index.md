---
layout: page
title: From operating lines to building process windows
category: Background
subtitle: Why manufacturability became the problem I care about.
description: Background on Nathan Anderson’s path from operator work to Georgia Tech chemical engineering, Filler Lab printed electronics, and process-development work.
---

<section class="access-feature tone-dark">
 <p class="system-label">Why access matters</p>
 <h2>Systems decide who gets to use the future.</h2>
 <p>Growing up adopted from Incheon into small-town Minnesota made me notice who systems are built for. That observation is why manufacturability, not just discovery, is the question I care about.</p>
</section>

<section class="background-depth reordered-background three-section-rhythm">
 <article>
  <h2>Why process engineering</h2>
  <p>I study process development for advanced manufacturing. At Filler Lab · Georgia Tech, micromodular printed-electronics work forced me to define inputs, <abbr title="Critical-to-Quality">CTQs</abbr>, screens, and failure modes instead of only describing what I observed.</p>
  <p>Earlier work at Mayo Clinic · Rochester, MN focused on microfluidic encapsulation throughput and thermocycler automation for biological protocols.</p>
 </article>
 <article>
  <h2>Why systems work</h2>
  <p>The useful question is not only whether a result worked once. It is whether the variables, tools, and people around it can make the result happen again.</p>
 </article>
 <article>
  <h2>Why future infrastructure</h2>
  <p>The future I care about is physical: cleaner factories, better wet labs, accessible biotech, resilient energy systems, and advanced manufacturing that reaches more than privileged rooms.</p>
 </article>
</section>

<section class="timeline-feature">
 <h2>Incheon → Minnesota → Georgia Tech → Filler Lab → Fall 2026</h2>
 <div class="horizontal-timeline visual-timeline" aria-label="Background timeline">
  <div><strong>Incheon</strong><span>Born in South Korea. Access became personal before it became technical.</span></div>
  <div><strong>Minnesota</strong><span>K–12 and early operator work. Learned service lines, queues, and throughput pressure.</span></div>
  <div><strong>Georgia Tech</strong><span>Chemical engineering, expected 2027. Transport, thermodynamics, controls, and manufacturing logic.</span></div>
  <div><strong>Filler Lab</strong><span>2025–present. Micromodular deposition screens and printed-electronics reliability.</span></div>
  <div><strong>Fall 2026</strong><span>Open for co-op, internship, paid trial project, or hard-tech startup role.</span></div>
 </div>
</section>

<section id="earlier-work" class="earlier-work-block artifact-panel standard-card-section">
 <h2>Before process engineering</h2>
 <div class="two-column-evidence">
  <article><h3>Earlier operator work</h3><p>QSR peak-hour operations taught bottleneck thinking, line balancing, changeover discipline, preventive maintenance, and shipping under pressure. One improvement cycle produced a +20% cars/hr increase by changing upstream prep, staffing, and bottleneck response.</p><span class="outcome-badge">+20% cars/hr</span></article>
  <article><h3>Earlier research</h3><p>DNA flexibility assay work gave early exposure to PCR, controls, repeatability, protocol discipline, and troubleshooting loops. It now sits as evidence of assay discipline rather than a flagship case file.</p><span class="outcome-badge">PCR controls</span></article>
 </div>
 <p class="next-line"><strong>Next:</strong> take the printed-interconnect failure classes from screen to a full control-plan draft, then validate across three substrates.</p>
</section>

<section class="mcdonalds-mini-case pull-quote-block">
 <p class="system-label">QSR operations mini-case</p>
 <p>Peak-hour operations made bottlenecks visible in minutes. Prep, sequencing, staffing, equipment uptime, and handoff timing behaved like a live control problem. That operator instinct now shows up in how I read wet-lab workflows and early manufacturing screens.</p>
</section>

<section class="background-tool-sidebar tools-section">
 <div>
  <h2>Tools and how I use them</h2>
  <p class="tool-rule">How I pick a tool: simplest tool that captures the variable. Python when it needs automation. JMP when it needs explanation.</p>
 </div>
 <div class="skill-use-grid logo-tool-grid">
  <div class="skill-use"><span class="tool-logo">Py</span><h3>Python</h3><p>Image analysis, droplet tracking, data processing, plotting, and workflow automation.</p></div>
  <div class="skill-use"><span class="tool-logo">M</span><h3>MATLAB</h3><p>Numerical methods, engineering computation, ODE workflows, and course-based modeling.</p></div>
  <div class="skill-use"><span class="tool-logo">J</span><h3>JMP</h3><p><abbr title="Analysis of Variance">ANOVA</abbr>, reliability/statistical analysis, comparisons, and experimental interpretation.</p></div>
  <div class="skill-use"><span class="tool-logo">A</span><h3>Aspen</h3><p>Process simulation, thermodynamics, separations, vapor-liquid equilibrium reasoning, and flowsheet calculations.</p></div>
  <div class="skill-use"><span class="tool-logo">IJ</span><h3>ImageJ/Fiji</h3><p>Microscopy/video segmentation, image calibration, and experimental measurement support.</p></div>
  <div class="skill-use"><span class="tool-logo">X</span><h3>Excel</h3><p>Engineering calculations, data organization, plots, screening tables, and communication-ready summaries.</p></div>
 </div>
</section>

<section class="background-depth refined-background-depth">
 <article><div class="background-cta-row"><a class="button primary" href="{{ '/projects/' | relative_url }}">View case files <span aria-hidden="true">→</span></a><a class="button secondary" href="{{ '/assets/files/Nathan_Anderson_Resume.pdf' | relative_url }}" download="Nathan_Anderson_Resume.pdf">Resume</a><a class="button tertiary" href="{{ '/contact/' | relative_url }}">Contact me</a></div></article>
</section>
