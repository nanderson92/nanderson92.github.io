# Projects Page Migration Note

Replace your existing `/projects/` folder with the contents of this folder.

This edited version intentionally removes the old standalone pages for:
- `droplet-image-analysis-workflows/`
- `droplet-image-analysis/`
- `process-simulation-design/`

The image-analysis workflow is now folded into the flagship `micromodular-deposition/` project, and process simulation is omitted until it has a concrete artifact.
